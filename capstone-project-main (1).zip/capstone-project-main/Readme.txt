Running Unit Tests

To run the unit tests, open the VS terminal and use the following command:

python manage.py test tests/

Make sure to activate the virtual environment and navigate to the littlelemon directory before executing the command:

cd littlelemon


---

API Endpoints for Testing

Use the following API paths for testing in Insomnia or Postman:

JDOSER Endpoints

Create a new user (POST request):
/auth/users/

Get authentication token:
/api-token-auth/

Login using JDOSER endpoint:
/auth/token/login


Menu Endpoints

Retrieve menu items:
/restaurant/menu/

Get details of a specific menu item by ID:
/restaurant/menu/{menuItemId}


Table Booking Endpoints

Book a table:
/restaurant/booking/tables/

View details of a specific table booking:
/restaurant/booking/tables/{bookingId}
